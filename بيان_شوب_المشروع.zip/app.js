
    console.log("Welcome to بيان شوب Application!");
    