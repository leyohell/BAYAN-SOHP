
console.log("بيان شوب يعمل ✅");
